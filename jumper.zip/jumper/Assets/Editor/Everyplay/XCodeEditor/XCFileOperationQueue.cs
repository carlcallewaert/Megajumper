using UnityEngine;
using System.Collections;

namespace Everyplay.XCodeEditor
{
	public class XCFileOperationQueue : System.IDisposable
	{
		public void Dispose()
		{

		}
	}
}
