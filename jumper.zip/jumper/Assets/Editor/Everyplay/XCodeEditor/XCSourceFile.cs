using UnityEngine;
using System.Collections;

namespace Everyplay.XCodeEditor
{
	public class XCSourceFile : System.IDisposable
	{
		public void Dispose()
		{

		}
	}
}
