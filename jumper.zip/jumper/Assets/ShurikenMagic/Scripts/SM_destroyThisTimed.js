
var destroyTime:float=5;

function Start () {
Destroy (gameObject, destroyTime);
}
function Update () {
}