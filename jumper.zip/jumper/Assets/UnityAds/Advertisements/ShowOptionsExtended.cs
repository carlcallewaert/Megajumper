﻿using System;

namespace UnityEngine.Advertisements.Optional {
  
  public class ShowOptionsExtended : ShowOptions {
    
    public string gamerSid { get; set; }
    
  }
  
}
