using System;

namespace UnityEngine.Advertisements {

  public enum ShowResult {
    Failed,
    Skipped,
    Finished
  }

}
